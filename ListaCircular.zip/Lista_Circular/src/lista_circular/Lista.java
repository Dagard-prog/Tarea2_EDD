/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista_circular;

import java.util.function.Function;

/**
 *
 * @author usuario
 */
public class Lista {
    Nodo inicio;
    Nodo fin;
    
    
    public Lista(){
        this.inicio=null;
        this.fin=null;    
    }
    
    public boolean  esta_vacio(){
        return this.inicio==null;    
    }
    
    
    public int contar(){
        if(esta_vacio())return 0;
        int contador=1;
       Nodo pivote = inicio;       
       while(pivote!=fin){
           pivote=pivote.siguiente;
           contador+=1;
       }
        return contador;
    }
    
    
    public void insertar_final(Object Elemento,int clave){
        Nodo nuevo_n=new Nodo(Elemento,clave);                
        if(!this.esta_vacio()){
            this.fin.siguiente=nuevo_n;
            fin=nuevo_n;
            fin.siguiente=inicio;            
        }else{
            this.inicio=nuevo_n;
            this.inicio.siguiente=inicio;
            this.fin=nuevo_n;
        }       
    }
    
    public void insertar_inicio(Object Elemento,int clave){
        Nodo nuevo_n=new Nodo(Elemento,clave);                
        if(!this.esta_vacio()){
            nuevo_n.siguiente=inicio;
            this.fin.siguiente=nuevo_n;
            this.inicio=nuevo_n;            
        }else{
            this.inicio=nuevo_n;
            this.inicio.siguiente=inicio;
            this.fin=nuevo_n;
        }           
    }
    
    public void imprimir(){
       if(this.esta_vacio()){System.out.println("La lista esta vacia");return;}
       Nodo pivote = inicio;              
       while(pivote!=fin){
           System.out.println("Nodo con valor: "+pivote.clave);
           pivote=pivote.siguiente;           
       }   
       System.out.println("Nodo con valor: "+pivote.clave);
    }

    
    

    
    
}
