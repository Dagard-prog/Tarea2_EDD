/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista_circular;

/**
 *
 * @author usuario
 */
public class Lista_Circular {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Lista l=new Lista();
        String elemento="A";
        
        //Prueba de insercion al inicio
//        l.insertar_final(elemento,1);
//        l.insertar_final(elemento,2);
//        l.insertar_final(elemento,3);
//        l.insertar_final(elemento,4);
//        l.insertar_final(elemento,5);

        //Prueba de insercion al final
        
        l.insertar_inicio(elemento,1);
        l.insertar_inicio(elemento,2);
        l.insertar_inicio(elemento,3);
        l.insertar_inicio(elemento,4);
        l.insertar_inicio(elemento,5);
        
        l.imprimir();
        System.out.println("Cantidad de elems:"+l.contar());
        System.out.println("Esta vacio: "+l.esta_vacio() );
        
        
        
    }
    
}
