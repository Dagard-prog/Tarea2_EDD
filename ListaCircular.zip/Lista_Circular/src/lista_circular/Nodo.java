/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista_circular;

/**
 *
 * @author usuario
 */
public class Nodo {
    Nodo siguiente;    
    Object elemento;
    int clave;
    
    public Nodo(Object elemento,int clave){
        this.siguiente=null;
        this.elemento=elemento;
        this.clave=clave;
    }
    
}
